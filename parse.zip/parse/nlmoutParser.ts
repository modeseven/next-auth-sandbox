import { isLineCentered } from "./parseHelpers";
import { parseLabelRow } from "./segments/labelRow";
import { Segment, Section } from "./segments/types";
import { RawTextRow } from "./segments/rawTextRow";
import { processors } from "./nlmoutParseConfig";

export type Processor = (lines: string[]) => Segment;


export function parseRawLinesToRows(rawLines: string[]): Segment[] {
    const rows: Segment[] = [];
    let collecting: boolean = false;
    let collectedLines: string[] = [];
    let currentProcessor: Processor | null = null;

    rawLines.forEach((line: string) => {
        const centered: boolean = isLineCentered(line);
        const empty: boolean = line.trim().length === 0;
        //    console.log("line", line);
        //   console.log("line timre longht", line.trim().length);
        //    console.log("-----------------------------------------------", empty);

        if (empty && collecting) {
            // End of table, process collected lines using the current processor
            collecting = false;
            if (currentProcessor) {
                const processedTable: Segment = currentProcessor(collectedLines);
                rows.push(processedTable);
            }
            currentProcessor = null; // Reset the processor
        } else if (collecting) {
            // Collect lines for the current table
            collectedLines.push(line);
        } else {
            // Check if the line matches any starting item in matchLines and select the processor
            // if nothign matches falls through to base parsing (label or raw text row)
            const match: string | undefined = Object.keys(processors).find(prefix => line.trim().startsWith(prefix));
            if (match) {
                console.log("found a match - collecting", match);
                collecting = true;
                collectedLines = [line];
                currentProcessor = processors[match];
            } else if (line.includes(": ")) {
                // TODO: we could probalby collect mark where the semi colon is.. and collect ones with identical postions
                // then process them all togetehr into aneat cluster like the legacy system.

                // Process as LabelRow
                rows.push(parseLabelRow(line)); // Assuming parseLabelRow is defined and returns a LabelRow
            } else {
                // Process as RawTextRow
                rows.push({
                    type: 'RawTextRow',
                    centered,
                    empty,
                    value: line.trim()
                } as RawTextRow);
            }
        }
    });
    return rows;
}


export function parseInputToSectionsOnly(input: string[]): Section[] {
    const sections: Section[] = [];
    let currentSection: Section | null = null;

    input.forEach(line => {
        // console.log("checking line", line);
        if (line.trim().startsWith("-")) {
            console.log("found a line with dashes", line);
            // This is a new section
            const label = line.replace(/-+/g, '').trim();
            if (currentSection) {
                sections.push(currentSection); // Push the previous section if it exists
            }
            // Start a new section
            currentSection = { label, rawLines: [], rows: [] };
        } else if (currentSection) {
            // Add line to current section
            currentSection.rawLines.push(line);
        }
    });

    if (currentSection) {
        sections.push(currentSection); // Push the last section
    }

    return sections;
}





