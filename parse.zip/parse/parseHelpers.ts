import { LabeledValue } from "./segments/labelRow";

export function isLineCentered(line: string): boolean {
    return line.startsWith(" ") && line.endsWith(" ");
}

export function getSubstringsFromRanges(ranges: [number, number][], subject: string): string[] {
    return ranges.map(([start, end]) => subject.substring(start, end + 1).trim());
}

export function getSubstringRanges(input: string): [number, number][] {
    const ranges: [number, number][] = [];
    const cleanedInput = input.replace(/(\b\w+\b)\s(\b\w+\b)/g, '$1|$2');
    const columns = cleanedInput.trim().split(/\s+/);

    // Find the start index for the first column, which is the first non-whitespace character
    let startIndex = cleanedInput.indexOf(columns[0]);
    ranges.push([0, startIndex - 1]);

    // Find the start and end index for each subsequent column
    for (let i = 0; i < columns.length - 1; i++) {
        let endIndex = cleanedInput.indexOf(columns[i + 1], startIndex) - 2;
        ranges.push([startIndex, endIndex]);
        startIndex = endIndex + 1;
    }

    // Add the range for the last column up to the end of the string
    ranges.push([startIndex, cleanedInput.length]);

    return ranges;
}

