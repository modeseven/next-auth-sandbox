import { OffenseCode } from "./offenseCode";
import { CategoricalTable } from "./categoryTable";
import { LabelRow } from "./labelRow";
import { LabeledTable } from "./labeledTable";
import { RawTextRow } from "./rawTextRow";


export interface Section {
    label: string;
    rawLines: string[];
    rows: BaseRow[];
}

export type Segment = LabelRow | RawTextRow | CategoricalTable | LabeledTable | OffenseCode;

export interface BaseRow {
    type: 'LabelRow' | 'RawTextRow' | 'CategoricalTable' | 'LabeledTable' | 'OffenseCode';
}




