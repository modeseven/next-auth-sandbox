import { Processor } from "./nlmoutParser";
import { CategoricalTableComponent, parseCategoryTable } from "./segments/categoryTable";
import { LabelRowComponent } from "./segments/labelRow";
import { LabeledTableComponent, parseLabeledTable } from "./segments/labeledTable";
import { OffenseCodeComponent, parseOffenseCode } from "./segments/offenseCode";
import { RawTextRowComponent } from "./segments/rawTextRow";


// Mapping matchLines to their corresponding processors
// these match on a row then collect all lines until an empty string.
// the captured lines are processed separately in the matched processor in to a MappedRow
export const processors: Record<string, Processor> = {
    "COL1     COL2   COL3   COL4": parseCategoryTable,
    "COL1 ASSES     COLX     COL3": parseCategoryTable,
    "JAIL CREDIT.": parseLabeledTable,
    "OFFENSE CODE": parseOffenseCode,
};

// add new components here
export const componentRegistry: { [key: string]: React.ComponentType<any> } = {
    LabelRow: LabelRowComponent,
    RawTextRow: RawTextRowComponent,
    CategoricalTable: CategoricalTableComponent,
    LabeledTable: LabeledTableComponent,
    OffenseCode: OffenseCodeComponent,
};
